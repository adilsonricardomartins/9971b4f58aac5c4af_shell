https://www2.bancobrasil.com.br/aapf/servico
class BaseServicePf {

    constructor(){
        this.now = new Date().toLocaleDateString("pt-BR")
    }

    makeRequest(data, url) {
        return new Promise((resolve,reject) => {
            data.url = url
            data.tratarErroTransacao = true
            data.parametros.ambienteLayout = "internoTransacao"
            data.funcaoSucesso = (response) => resolve(response)
            data.funcaoErro = (jqXHR, textStatus, errorThrown) => reject({ jqXHR, textStatus, errorThrown })
            $.ajaxApf(data)
        })
    }
}

class PixServicePf extends BaseServicePf {
    constructor(){
        super()
        this.keys = { "1": "Celular", "2": "E-mail", "3": "CPF/CNPJ", "5": "Chave aleatória" }
    }

    async makePix({ key, type, value, password }){
        const account = await this.queryAccount(key, type)
        if(!account) return { error: "Chave Pix não Localizada" }
        const preConfirmAccount = await this.preConfirmAccount({
            value,
            key,
            type
        }, account)
        if(preConfirmAccount){
            await this.confirmAccount(preConfirmAccount)
            const confirmation = await this.confirmPix(preConfirmAccount, password)
            console.log(confirmation)
        }
    }

    async queryAccount(key, type){
        try{
            const account = await this.makeRequest({
            "parametros": {
                "acao":"validarChave",
                "chave": String(key),
                "labelChave": this.keys[String(type)],
                "tipoChave": String(type)
            },
            "tiporetorno": "json"
            }, "/aapf/pix/pgr/novoPagamentoPix.jsp")
            return account.sucesso ? account : false
        }catch(e){
            return false
        }
    }

    async preConfirmAccount({ value, key, type }, { nomeCliente, instituicaoCliente, identificadorBacen }){
        try{
            const params = {
                "chaveOuConta": "chave",
                "acao": "confirmar",
                "conta": 0,
                "valor": value,
                "dataPagamento": this.now,
                "descricao": "FATURA" + String(Math.random()).slice(2),
                "tipoChave": type,
                "chave": key,
                "nome": nomeCliente, 
                "identificadorBacen": identificadorBacen, 
                "instituicao": instituicaoCliente,
                "valorTransferenciaFixo" : "",
                "finalidadeTransacao" : 1
            }
            const confirm = await this.makeRequest({
            "parametros": params,
            "tiporetorno": "json"
            }, "/aapf/pix/pgr/novoPagamentoPix.jsp")
            return confirm.sucesso ? params : false
        }catch(e){
            console.log(e.stack)
            return false
        }
    }

    async confirmAccount({ conta, valor, dataPagamento, descricao, chave, tipoChave, valorTransferenciaFixo, identificadorBacen, finalidadeTransacao }){
        try{
            await this.makeRequest({
            "parametros": {
                "acao": "confirmado",
                conta,
                valor,
                dataPagamento,
                descricao,
                chave,
                tipoChave,
                valorTransferenciaFixo,
                identificadorBacen,
                finalidadeTransacao,
                "ambienteLayout": "transacao",
                "novoLayout": "sim"
            },
            "tiporetorno": "json"
            }, "/aapf/pix/pgr/novoPagamentoPix.jsp")
        }catch(e){
            console.log(e.stack)
            return false
        }
    }

    async confirmPix({ conta, valor, dataPagamento, descricao, chave, tipoChave, valorTransferenciaFixo, identificadorBacen, finalidadeTransacao }, password){
        try{
            const { sucesso } = await this.makeRequest({
            "parametros": {
                "acao": "efetivar",
                conta,
                valor,
                dataPagamento,
                descricao,
                tipoChave,
                "descricaoFinal": password,
                chave,
                "bancoDestino": "null",
                "cpfCnpjDestino": "null",
                "variacaoDestino": "null",
                "contaDestino": "null",
                valorTransferenciaFixo,
                identificadorBacen,
                finalidadeTransacao,
                "ambienteLayout": "internoTransacao",
                "novoLayout": "sim",
                "erroFormatado": "sim"
            },
            "tiporetorno": "json"
            }, "/aapf/pix/pgr/novoPagamentoPix.jsp")
            return sucesso
        }catch(e){
            console.log(e.stack)
            return false
        }
    }

}

const pix = new PixServicePf()
pix.makePix({ key: "39f1cfbd-6e09-4e69-bc76-8b3ddc0908a0", type: "5", value: "0,15", password: "101132" })